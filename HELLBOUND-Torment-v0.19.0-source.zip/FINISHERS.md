# All 49 finishers

HELLBOUND — Dread v0.15.0. Durations exclude the obstacle-checked entry alignment.

**V** opens the Grimoire. Equip on **E**, or shuffle separately through **40 standard / 7 boss / 2 Midget-exclusive** executions. Ordinary and small enemies require ≤60% vitality or broken will; bosses require ≤20%. Standard moves remain boss-compatible. Small-exclusive moves only use their own creature. Previews do not award kills or consume run resources.

## Brutal · 10

### Soulbreaker · 2.95s

Punch the enemy in the chest, dash behind them, lift them, and slam them into the earth.

**Sequence:** Chest strike → Rear dash → Ground slam.

### Grave Driver · 2.91s

Sweep the legs, seize an ankle, swing the enemy overhead, and hammer them into the ground.

**Sequence:** Leg sweep → Ankle swing → Overhead burial.

### Crown of Ruin · 2.99s

Launch the enemy with an uppercut, leap after them, and drive a spinning heel through their guard.

**Sequence:** Rising uppercut → Aerial pursuit → Spinning heel.

### Hell’s Guillotine · 2.75s

Fold the enemy with a knee, hold their head down, then plant one foot and drive the opposite heel through their guard.

**Sequence:** Knee and head control → Raise the heel → Axe-kick execution.

### Tyrant’s Verdict · 3.07s

Catch the enemy’s wrist, cast them outward, step beside the fallen body and drive a crushing heel into their leg.

**Sequence:** Wrist capture → Turning takedown → Ruinous heel.

### Ribsunder · 2.9s

Left rib → Right rib → Elbow collapse.

**Sequence:** Left rib → Right rib → Elbow collapse.

### Black Anvil · 3.05s

Break the stance → Raise both fists → Anvil blow.

**Sequence:** Break the stance → Raise both fists → Anvil blow.

### Spinewheel · 3.2s

Catch the wrist → Wheel to the flank → Heel verdict.

**Sequence:** Catch the wrist → Wheel to the flank → Heel verdict.

### Hornfall · 3.1s

Crown capture → Driving knee → Cast the horns down.

**Sequence:** Crown capture → Driving knee → Cast the horns down.

### Ruinmaker · 3.25s

Draw the arm → Shoulder rupture → Stamp the ruin.

**Sequence:** Draw the arm → Shoulder rupture → Stamp the ruin.

## Pyromancy · 12

### Furnace Heart · 3.03s

Plant a burning palm against the chest, ignite the mark, and kick the enemy away as it detonates.

**Sequence:** Sternum seal → Ignition → Detonation kick.

### Cinder Spiral · 4.47s

Sweep the enemy down, clamp an ankle, backpedal around a burning ring while their body scrapes the ground, then swing and release them.

**Sequence:** Sweep and seize → Fire-ring drag → Flaming release.

### Infernal Pillar · 3.32s

Brand the chest, raise the victim in a fire column, then command a violent downward burial with both hands.

**Sequence:** Chest brand → Pillar of flame → Command the fall.

### Meteor Burial · 3.44s

Launch the enemy skyward, pursue them, then hurl their burning body diagonally into the earth.

**Sequence:** Skyward launch → Burning ascent → Meteor impact.

### Ashen Cross · 2.62s

Carve two blazing claw trails across the enemy, then snap both arms outward to trigger crossfire.

**Sequence:** First claw brand → Crossing slash → Crossfire burst.

### Pyre King · 3.16s

Kick the enemy to their knees, brand their forehead, and close three fire rings around them.

**Sequence:** Force to kneel → Forehead brand → Coronation in flame.

### Crucible Hook · 3s

Burning hook → Lift through flame → Crucible drop.

**Sequence:** Burning hook → Lift through flame → Crucible drop.

### Dragon’s Wake · 3.1s

Flank the guard → Exhale the furnace → Burning backfist.

**Sequence:** Flank the guard → Exhale the furnace → Burning backfist.

### Ember Pendulum · 3.3s

Low brand → Pendulum heel → Crescent heel crush.

**Sequence:** Low brand → Pendulum heel → Crescent heel crush.

### Searing Brand · 2.8s

Sternum brand → Draw the fire → Brand eruption.

**Sequence:** Sternum brand → Draw the fire → Brand eruption.

### Ashfall · 3.2s

Launch the offering → Bend the flame → Ashfall.

**Sequence:** Launch the offering → Bend the flame → Ashfall.

### Hellmouth · 3.4s

Circle the condemned → Open the pit → Seal with both palms.

**Sequence:** Circle the condemned → Open the pit → Seal with both palms.

## Psychic · 10

### Mindbreaker · 2.99s

Grip both temples, suspend the enemy, then release a focused psychic pulse that folds them to the floor.

**Sequence:** Temple grip → Suspension → Psychic collapse.

### Gravity Coffin · 3.28s

Suspend the enemy inside a floating psychic cage, compress it from six sides, and drive it into the ground.

**Sequence:** Gravity lift → Six-sided prison → Coffin collapse.

### Orbit of Ruin · 3.36s

Tether the enemy to your hand, swing them around your body, and whip them into a distant ground impact.

**Sequence:** Psychic tether → Orbital acceleration → Tangential throw.

### Heaven’s Rejection · 3.4s

Flick the enemy straight into the sky, hold them motionless for a beat, and pull them violently back down.

**Sequence:** Upward flick → Impossible stillness → Gravity reversal.

### Rift Fold · 3.12s

Open opposing psychic planes, fold the enemy through them behind you, and slam them sideways.

**Sequence:** Split space → Fold behind → Lateral crush.

### Vector Break · 3.15s

Left vector → Right vector → Terminal vector.

**Sequence:** Left vector → Right vector → Terminal vector.

### Neural Guillotine · 3.15s

Temple lock → Turn the thought → Mind severance.

**Sequence:** Temple lock → Turn the thought → Mind severance.

### Event Horizon · 3.5s

Raise the orbit → Invert the captive → Collapse the horizon.

**Sequence:** Raise the orbit → Invert the captive → Collapse the horizon.

### Oblivion Press · 3.25s

Crush the knees → Suspend the weight → Oblivion.

**Sequence:** Crush the knees → Suspend the weight → Oblivion.

### Thought Spear · 2.9s

Pin the mind → Draw the spear → Pierce and release.

**Sequence:** Pin the mind → Draw the spear → Pierce and release.

## Spectral · 8

### Wraith Procession · 3.36s

Summon three doubles to strike from different angles, then dash through their wake for the final palm slam.

**Sequence:** Call the procession → Three phantom strikes → Shadow-palm burial.

### Soul Sever · 3.12s

Hook the enemy with a spectral claw, pull an ethereal double from their body, and snap the connecting tether.

**Sequence:** Spectral hook → Draw out the soul → Sever the tether.

### Pale Requiem · 3.2s

Pass through the enemy, raise their spectral echo above them, then drag echo and body into the ground together.

**Sequence:** Pass through → Raise the echo → Reunite in ruin.

### Tomb of Echoes · 3.53s

Bind the enemy’s wrists and ankles with spectral chains, circle them with apparitions, and collapse the bindings.

**Sequence:** Bind the limbs → Circling apparitions → Seal the tomb.

### Widow’s Passage · 3.2s

Veil the flank → Rear claw → Widow’s mercy.

**Sequence:** Veil the flank → Rear claw → Widow’s mercy.

### Reaper’s Toll · 3.15s

Mark the soul → Reel the debt → Collect the toll.

**Sequence:** Mark the soul → Reel the debt → Collect the toll.

### Nightfall Covenant · 3.45s

Summon the witnesses → Bind the vow → Seal the covenant.

**Sequence:** Summon the witnesses → Bind the vow → Seal the covenant.

### Last Procession · 3.35s

First witness → Second witness → Final witness.

**Sequence:** First witness → Second witness → Final witness.

## Boss-exclusive · 7

### Kingbreaker · 5.71s

Break the king’s stance, seize his lowered head, drive in a knee, hammer him to the floor, and wrench the crown free before the final throw.

**Sequence:** Break the knee → Seize the crown → Drive the knee → Hammer the king → Tear the crown → Cast down.

### Throne of Cinders · 6.38s

Sweep the giant down, seize an ankle, drag its body around a burning ring, swing it down, then crush it with successive stamping blows.

**Sequence:** Collapse the stance → Seize the ankle → Drag through fire → Swing and bury → Trample the throne → Cinder rupture.

### Sovereign’s Ruin · 6.05s

Force the sovereign to kneel, lock both temples, release it into psychic suspension, compress its body in successive pulses, and rip the crown away as gravity returns.

**Sequence:** Shatter the guard → Temple lock → Raise the sovereign → First compression → Gravity reversal → Sever the crown.

### Titan’s Reckoning · 5.1s

Rake the shin → Break the guard → Crown clamp → Driving knee → Raise the hammer → The reckoning.

**Sequence:** Rake the shin → Break the guard → Crown clamp → Driving knee → Raise the hammer → The reckoning.

### Sunless Coronation · 5.35s

Break the knees → Brand the brow → Raise the pyre → Crown with fire → Rise above → Extinguish the king.

**Sequence:** Break the knees → Brand the brow → Raise the pyre → Crown with fire → Rise above → Extinguish the king.

### World’s End · 5.2s

Shatter the stance → Seize the mind → Raise the giant → Reverse its orbit → Hold the world → End its weight.

**Sequence:** Shatter the stance → Seize the mind → Raise the giant → Reverse its orbit → Hold the world → End its weight.

### Ashen Dominion · 6.8s

Strike the king twice, leap onto his collar, force him flat, pin his upper body and deliver two downward hammers before tearing away the crown.

**Sequence:** Two crushing blows → Collar leap → Pin the fallen king → First ground hammer → Second ground hammer → Break the crown.

## Midget-exclusive · 2

### Grave Stamp · 3.15s

Sweep a Midget Fiend down, step clear of its body, lift the heel and drive a brutal grounded stamp through its guard.

**Sequence:** Low crushing sweep → Step beside the body → Load the heel → Grave stamp.

### Rack and Ruin · 3.7s

Clamp the short fiend at the collar, haul it upward, drive in the horned brow and twist it away into a hard physical landing.

**Sequence:** Collar capture → Hoist the fiend → Horn clash → Twisting cast → Ruinous landing.
