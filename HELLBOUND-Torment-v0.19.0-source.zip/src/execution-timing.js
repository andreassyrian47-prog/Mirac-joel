import {curve} from './motion.js';
import {accentExecution} from './execution-rhythm.js';
// Preserve each move's beat order, but reserve only 180ms for its final release.
// Anticipation is allowed to breathe; the actual drop is never eased over half a second.
export function executionTime(seconds,def){
 if(def.bespoke)return Math.min(seconds,def.duration);
 const u=Math.min(1,seconds/def.duration),I=def.impact,release=.18/def.duration;
 return accentExecution(curve([[0,0],[I-.23,I-.23],[I-release,I-.14],[I,I],[1,1]],u),def)*def.duration;
}
