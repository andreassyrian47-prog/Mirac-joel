# HELLBOUND — The Ashen Wake
## TORMENT · v0.19.0 — style consequence, chain executions, bestiary kits, living menu

Wave 4 (TORMENT) adds: **style consequence** (the D→SSS meter multiplies souls/ascension, rank-up ceremonies, Style Conduit refunds 25–40% cast wrath), **chain executions** (post-finisher chain window, 1.7× pace kills), **bestiary fidelity kits** (distinct silhouettes per enemy kind, crowned Cinder King with molten core), and a **living orbital menu**. See `TORMENT.md`.

Wave 3 (MALICE) adds: **run-in attack blending** (attacks begun at speed arrive with momentum — hip drop, lean, step), **spellweave cast steering** (casts steer toward their target through the windup), an **execution impact dolly** (instantaneous FOV pinch + distance punch at the blow), and **realm hunts** (scripted ambush packs in Free Roam: "THE REALM HUNTS BACK"). See `MALICE.md`.

A playable desktop-browser third-person demon action prototype: four modes, four connected districts, **49 executions**, **24 powers**, and stance-driven melee. Built with Three.js, procedural articulated characters and lightweight constrained ragdolls. This is a contained prototype, not a campaign-sized open-world RPG or a motion-captured AAA game.

